<?php $__env->startSection('title', 'Post Show'); ?>



<?php $__env->startSection('content'); ?>
    
    <!-- Page Title -->
    <section class="page-title style-two" style="background-image:url(images/background/1.jpg)">
        <div class="auto-container">
            <h1>Blog Detail</h1>
            <ul class="page-breadcrumb">
                <li><a href="<?php echo e(url('/')); ?>">home</a></li>
                <li>Blog Detail</li>
            </ul>
        </div>
    </section>
    <!-- End Page Title -->

    <!-- Sidebar Page Container -->
    <div class="sidebar-page-container">
        <div class="auto-container">
            <div class="row clearfix">

                <!-- Content Side -->
                <div class="content-side col-lg-8 col-md-12 col-sm-12">
                    <!-- Block Detail -->
                    <div class="blog-detail">
                        <div class="inner-box">
                            <div class="image">
                                <img src="images/resource/news-3.jpg" alt="" />
                                <div class="category">Business</div>
                                <ul class="post-meta">
                                    <li><span
                                            class="icon flaticon-timetable"></span><?php echo e(Carbon\Carbon::parse($post->created_at)->format('M d, Y ')); ?>

                                    </li>
                                    <li><span class="icon flaticon-email"></span>Comments 03</li>
                                    <li><span class="icon flaticon-user-2"></span>Admin</li>
                                </ul>
                            </div>
                            <div class="lower-content">
                                <h3><?php echo e($post->title); ?>.</h3>
                                <p><?php echo $post->description; ?>. </p>
                                
                                <?php if($post->quote): ?>
                                    <blockquote>
                                        <span class="quote-icon flaticon-quote-1"></span>
                                        <div class="quote-text">"<?php echo $post->quote; ?>”</div>
                                        <div class="quote-author"><?php echo e($post->quoteby); ?></div>
                                    </blockquote>
                                <?php endif; ?>

                                <p><?php echo $post->snddescription; ?></p>
                                <div class="two-column">
                                    <div class="row clearfix">
                                        <!-- Column -->
                                        <div class="column col-lg-6 col-md-6 col-sm-12">
                                            <div class="image">
                                                <img src="<?php echo e(asset('image/post/' . $post->scndimage)); ?>"
                                                    alt="<?php echo e($post->scndimage); ?>" />
                                            </div>
                                        </div>
                                        <!-- Column -->
                                        <div class="column col-lg-6 col-md-6 col-sm-12">
                                            <p><?php echo $post->thddescription; ?>.</p>
                                            
                                        </div>
                                    </div>
                                </div>

                                <!-- Post Share Options-->
                                <div class="post-share-options">
                                    <div class="post-share-inner clearfix">
                                        
                                        <div class="tags pull-left">
                                            <div class="business">Category: <a href="#">Online Law</a>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="#"><?php echo e($category); ?>,</a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Blog Author Box -->
                            <div class="blog-author-box">
                                <div class="author-inner">
                                    <div class="thumb"><img src="<?php echo e(asset('/image/user/'.$post->User->image)); ?>"
                                            alt=""></div>
                                    <h4 class="name"><?php echo e($post->User->name); ?></h4>
                                    <div class="text"><?php echo $post->User->description; ?></div>
                                    <ul class="social-icon clearfix">
                                        <li><a href="<?php echo e($post->User->facebook); ?>"><i class="fa fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                        <li><a href="<?php echo e($post->User->twitter); ?>"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-skype"></i></a></li>
                                        <li><a href="<?php echo e($post->User->linkedin); ?>"><i class="fa fa-linkedin"></i></a></li>
                                    </ul>
                                </div>
                            </div>

                        </div>

                        


                        <!-- Comment Form -->
                        


                    </div>
                </div>

                <!-- Sidebar Side -->
                <div class="sidebar-side col-lg-4 col-md-12 col-sm-12">
                    <aside class="sidebar sticky-top">
                        <div class="sidebar-inner">

                            <!-- Search -->
                            <div class="sidebar-widget search-box">
                                <form method="post" action="https://html.designingmedia.com/counsel-law/contact.html">
                                    <div class="form-group">
                                        <input type="search" name="search-field" value=""
                                            placeholder="Search ....." required>
                                        <button type="submit"><span class="icon fa fa-search"></span></button>
                                    </div>
                                </form>
                            </div>

                            <!--Blog Category Widget-->
                            <div class="sidebar-widget sidebar-blog-category">
                                <div class="widget-content">
                                    <div class="sidebar-title">
                                        <h5>Categories</h5>
                                    </div>
                                    <ul class="cat-list-two">
                                        <?php $__empty_1 = true; $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <li><a href="#"><?php echo e($category->name); ?><span>(25)</span></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                        <?php endif; ?>

                                        
                                    </ul>
                                </div>
                            </div>

                            <!-- Popular Post Widget -->
                            <div class="sidebar-widget popular-posts">
                                <div class="widget-content">
                                    <div class="sidebar-title">
                                        <h5>latest posts</h5>
                                    </div>
                                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <article class="post">
                                            <figure class="post-thumb"><img
                                                    src="<?php echo e(asset('image/post/'.$post->image)); ?>"
                                                    alt=""><a href="<?php echo e(route('home.post.show',$post->id)); ?>" class="overlay-box"></a>
                                            </figure>
                                            <div class="text"><a href="<?php echo e(route('home.post.show',$post->id)); ?>"><?php echo e(Str::limit($post->title,30)); ?></a></div>
                                            <div class="post-info"><?php echo e(Carbon\Carbon::parse($post->created_at)->format('M d, Y ')); ?></div>
                                        </article>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    
                                </div>
                            </div>

                            <!-- Tags Widget -->
                            

                        </div>
                    </aside>
                </div>

            </div>
        </div>
    </div>

    

 

    <!-- CTA Section -->
    <section class="cta-section">
        <div class="auto-container">
            <div class="inner-container">
                <div class="image">
                    <img src="<?php echo e(URL::asset('frontend/images/resource/cta.jpg')); ?>" alt="" />
                </div>
                <div class="content">
                    <h2>Speak With Our <br> Experts Today!</h2>
                    <a href="contact.html" class="theme-btn btn-style-two"><span class="txt">Get a quote <i
                                class="arrow flaticon-right"></i></span></a>
                </div>
                <div class="hammer-image">
                    <img src="<?php echo e(URL::asset('frontend/images/resource/hammer.png')); ?>" alt="" />
                </div>
            </div>
        </div>
    </section>
    <!-- End CTA Section -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\law\law\resources\views/frontend/post/show.blade.php ENDPATH**/ ?>