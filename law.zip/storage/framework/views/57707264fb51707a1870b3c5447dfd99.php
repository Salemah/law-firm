
<!DOCTYPE html>
<html>

<!-- Mirrored from html.designingmedia.com/counsel-law/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 11 Nov 2023 15:27:12 GMT -->

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $__env->yieldContent('title'); ?>
    </title>
    <?php
        $dashboard_settings = \Illuminate\Support\Facades\DB::table('dashboard_settings')->first();
    ?>

    <link href="<?php echo e(asset('frontend/css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/css/responsive.css')); ?>" rel="stylesheet">

    <link
        href="https://fonts.googleapis.com/css2?family=Bellefair&amp;family=Open+Sans:wght@300;400;700;800&amp;family=Oswald:wght@400;500;600;700&amp;display=swap"
        rel="stylesheet">

    <link rel="shortcut icon"
        href="<?php if($dashboard_settings): ?> <?php echo e(asset('image/dashboard/' . $dashboard_settings->favicon)); ?> <?php else: ?> <?php echo e(asset('image/AdminLTELogo.png')); ?> <?php endif; ?> "
        type="image/x-icon">
    <link rel="icon"
        href="<?php if($dashboard_settings): ?> <?php echo e(asset('image/dashboard/' . $dashboard_settings->favicon)); ?> <?php else: ?> <?php echo e(asset('image/AdminLTELogo.png')); ?> <?php endif; ?> "
        type="image/x-icon">


    <!-- Responsive -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">


</head>

<body class="hidden-bar-wrapper">

    <div class="page-wrapper">

        <!-- Preloader -->
        

        <!-- Main Header-->
        <?php echo $__env->make('frontend.shared.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Main Header -->

        <?php echo $__env->yieldContent('content'); ?>



    <!-- CTA Section -->
    <section class="cta-section">
        <div class="auto-container">
            <div class="inner-container">
                <div class="image">
                    <img src="<?php echo e(URL::asset('frontend/images/resource/cta.jpg')); ?>" alt="" />
                </div>
                <div class="content">
                    <h2>Speak With Our <br> Experts Today!</h2>
                    <a href="<?php echo e(route('home.contact')); ?>" class="theme-btn btn-style-two"><span class="txt">Get a quote <i
                                class="arrow flaticon-right"></i></span></a>
                </div>
                <div class="hammer-image">
                    <img src="<?php echo e(URL::asset('frontend/images/resource/hammer.png')); ?>" alt="" />
                </div>
            </div>
        </div>
    </section>
    <!-- End CTA Section -->
 <!-- Messenger Chat Plugin Code -->
    <div id="fb-root"></div>

    <!-- Your Chat Plugin code -->
    <div id="fb-customer-chat" class="fb-customerchat">
    </div>
        <?php echo $__env->make('frontend.shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    </div>
    <!-- Messenger Chat Plugin Code -->



    <!--Scroll to top-->
    <div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>


    </div>

    <script>
      var chatbox = document.getElementById('fb-customer-chat');
      chatbox.setAttribute("page_id", "100499722787165");
      chatbox.setAttribute("attribution", "biz_inbox");
    </script>

    <!-- Your SDK code -->
    <script>
      window.fbAsyncInit = function() {
        FB.init({
          xfbml            : true,
          version          : 'v18.0'
        });
      };

      (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));
    </script>
    <?php echo $__env->make('frontend.layouts.partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

<!-- Mirrored from html.designingmedia.com/counsel-law/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 11 Nov 2023 15:27:32 GMT -->

</html>
<?php /**PATH D:\laragon\www\law\law\resources\views/frontend/master.blade.php ENDPATH**/ ?>