
     <?php
        $dashboard_settings = \Illuminate\Support\Facades\DB::table('dashboard_settings')->first();
    ?>
<footer class="main-footer">
    <strong>Copyright &copy; <?php echo e(Carbon\Carbon::now()->format('Y')); ?> <a href="<?php echo e($dashboard_settings->website); ?>"><?php echo e($dashboard_settings->copyright); ?></a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.0.5
    </div>
  </footer>
<?php /**PATH D:\laragon\www\law\law\resources\views/admin/dashboard/layouts/partials/footer.blade.php ENDPATH**/ ?>