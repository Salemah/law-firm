
<script src="<?php echo e(asset('frontend/js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/jquery.fancybox.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/appear.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/parallax.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/tilt.jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/jquery.paroller.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/owl.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/wow.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/nav-tool.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/script.js')); ?>"></script>
<?php /**PATH D:\laragon\www\law\law\resources\views/frontend/layouts/partials/script.blade.php ENDPATH**/ ?>