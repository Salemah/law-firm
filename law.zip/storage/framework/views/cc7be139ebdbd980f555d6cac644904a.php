<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/js/toastr.js"></script>
<!-- jQuery -->
<script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap -->
<script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE -->
<script src="<?php echo e(asset('js/adminlte.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<!-- OPTIONAL SCRIPTS -->

<script src="<?php echo e(asset('js/demo.js')); ?>"></script>
<script src="<?php echo e(asset('js/pages/dashboard3.js')); ?>"></script>
<script>
    $(document).ready(function() {
        toastr.options.timeOut = 10000;
        <?php if(Session::has('toastr-error')): ?>
        toastr.error('<?php echo e(Session::get('error')); ?>');
        <?php elseif(Session::has('success')): ?>
        toastr.success('<?php echo e(Session::get('toastr-success')); ?>');
        <?php endif; ?>
    });

</script>
<?php echo $__env->yieldPushContent('script'); ?>
<?php /**PATH D:\laragon\www\law\law\resources\views/admin/dashboard/layouts/script.blade.php ENDPATH**/ ?>