<?php $__env->startSection('title', 'Cases'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Title -->
    <section class="page-title style-two" style="background-image:url(images/background/1.jpg)">
        <div class="auto-container">
            <h1>Case studies</h1>
            <ul class="page-breadcrumb">
                <li><a href="index.html">home</a></li>
                <li>Case studies</li>
            </ul>
        </div>
    </section>
    <!-- End Page Title -->

    <!-- case-style-three -->
    <section class="case-style-three bg-color-1">
        <div class="auto-container">
            <div class="row clearfix">

                <?php $__currentLoopData = $cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $case): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-sm-12 case-block">
                        <div class="case-block-two wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <figure class="image-box">
                                    <img src="<?php echo e(URL::asset('/image/case/' . $case->image . '')); ?>" alt="">
                                    <div class="link"><a href="<?php echo e(route('home.cases.details',$case->id)); ?>"><i class="flaticon-link"></i></a></div>
                                    <div class="overlay-layer"></div>
                                </figure>
                                <div class="lower-content">
                                    <div class="box">
                                        <div class="icon-box"><i class="<?php echo e($case->legal->icon); ?>"></i></div>
                                        <p>Law Firm</p>
                                        <h4><a href="<?php echo e(route('home.cases.details',$case->id)); ?>"><?php echo e($case->legal->name); ?></a></h4>
                                    </div>
                                    <div class="text">
                                        <p><?php echo e($case->name); ?></p>
                                    </div>
                                    <div class="link"><a href="<?php echo e(route('home.cases.details',$case->id)); ?>"><i class="flaticon-right"></i>Read
                                            More</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo $cases->links(); ?>


            </div>
        </div>
    </section>
    <!-- case-style-three end -->



    <!-- Clients Section -->
    <section class="clients-section">
        <div class="auto-container">
            <!-- Sec Title -->
            <div class="sec-title centered">
                <h2>TRUSTED COMPANIES</h2>
                <div class="text">Nemo enim ipsam voluptatem quia voluptas sit asper aut odit aut fugit, sed quia
                    consequuntur magni doloreos <br> qui ratione voluptatem sequi nesciunt aorro ruisea</div>
            </div>
            <div class="inner-container">
                <div class="sponsors-outer">
                    <!--Sponsors Carousel-->
                    <ul class="sponsors-carousel owl-carousel owl-theme">
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="slide-item">
                                <figure class="image-box"><a href="#"><img
                                            src="<?php echo e(URL::asset('image/company/'.$company->image.'')); ?>" alt=""></a>
                                </figure>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- End Clients Section -->

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\law\law\resources\views/frontend/post/cases.blade.php ENDPATH**/ ?>