<?php $__env->startSection('title', 'Home Page'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Title -->
    <section class="page-title style-two" style="background-image:url(<?php echo e(asset('frontend/images/background/1.jpg')); ?>)">
        <div class="auto-container">
            
        </div>
    </section>
    <!-- End Page Title -->

    <!-- Sidebar Page Container -->
    <div class="sidebar-page-container">
        <div class="auto-container">
            <div class="row clearfix">

                <!-- Content Side -->
                <div class="content-side col-lg-8 col-md-12 col-sm-12">
                    <div class="blog-classic">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- News Block -->
                            <div class="news-block">
                                <div class="inner-box">
                                    <div class="image">
                                        <a href="<?php echo e(route('home.post.show',$post->id)); ?>"><img src="<?php echo e(asset('image/post/' . $post->image)); ?>"
                                                style="height: 70%" alt="" /></a>
                                        <div class="category">Law</div>
                                        <ul class="post-meta">
                                            <li><a href="<?php echo e(route('home.post.show',$post->id)); ?>"><span
                                                        class="icon flaticon-timetable"></span><?php echo e(Carbon\Carbon::parse($post->created_at)->format('M d, Y ')); ?></a>
                                            </li>
                                            <li><a href="<?php echo e(route('home.post.show',$post->id)); ?>"><span class="icon flaticon-email"></span>Comments
                                                    03</a></li>
                                            <li><a href="<?php echo e(route('home.post.show',$post->id)); ?>"><span
                                                        class="icon flaticon-user-2"></span>Admin</a></li>
                                        </ul>
                                    </div>
                                    <div class="lower-content">
                                        <h4><a href="<?php echo e(route('home.post.show',$post->id)); ?>"><?php echo e(Str::limit($post->title,250)); ?></a></h4>
                                        
                                        <div class="btn-box">
                                            <a href="<?php echo e(route('home.post.show',$post->id)); ?>" class="theme-btn btn-style-two"><span
                                                    class="txt">Learn More</span></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        

                    </div>
            <span style="padding-top: 40px">
                <?php echo $posts->links(); ?>

                </span>
                    <!--Post Share Options-->
                    

                </div>

                <!-- Sidebar Side -->
                <div class="sidebar-side col-lg-4 col-md-12 col-sm-12">
                    <aside class="sidebar sticky-top">
                        <div class="sidebar-inner">

                            <!-- Search -->
                            <div class="sidebar-widget search-box">
                                <form method="post" action="https://html.designingmedia.com/counsel-law/contact.html">
                                    <div class="form-group">
                                        <input type="search" name="search-field" value=""
                                            placeholder="Search ....." required>
                                        <button type="submit"><span class="icon fa fa-search"></span></button>
                                    </div>
                                </form>
                            </div>

                            <!--Blog Category Widget-->
                            <div class="sidebar-widget sidebar-blog-category">
                                <div class="widget-content">
                                    <div class="sidebar-title">
                                        <h5>Categories</h5>
                                    </div>
                                    <ul class="cat-list-two">
                                         <?php $__empty_1 = true; $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <li><a href="#"><?php echo e($category->name); ?><span>(25)</span></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>

                            <!-- Popular Post Widget -->
                            <div class="sidebar-widget popular-posts">
                                <div class="widget-content">
                                    <div class="sidebar-title">
                                        <h5>latest posts</h5>
                                    </div>
                                     <?php $__currentLoopData = $ltposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <article class="post">
                                            <figure class="post-thumb"><img
                                                    src="<?php echo e(asset('image/post/'.$postt->image)); ?>"
                                                    alt=""><a href="<?php echo e(route('home.post.show',$postt->id)); ?>" class="overlay-box"></a>
                                            </figure>
                                            <div class="text"><a href="<?php echo e(route('home.post.show',$postt->id)); ?>"><?php echo e(Str::limit($postt->title,30)); ?></a></div>
                                            <div class="post-info"><?php echo e(Carbon\Carbon::parse($postt->created_at)->format('M d, Y ')); ?></div>
                                        </article>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                            <!-- Tags Widget -->
                            

                        </div>
                    </aside>
                </div>

            </div>
        </div>
    </div>

    <!-- Facts Section three -->
    

    <!-- Clients Section -->
    
    <!-- End CTA Section -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\law\law\resources\views/frontend/post/all-post.blade.php ENDPATH**/ ?>