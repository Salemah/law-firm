
     <?php
        $dashboard_settings = \Illuminate\Support\Facades\DB::table('dashboard_settings')->first();
    ?>


<header class="main-header header-style-one">
    <!--Header-Upper-->
    <div class="header-upper">
        <div class="auto-container clearfix">

            <div class="pull-left logo-box">
                
                <div class="logo"><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/image/dashboard/'.$dashboard_settings->logo)); ?>" style="width: 100%;height:70px" alt="" title=""></a></div>
            </div>

            <div class="nav-outer clearfix">
                <!-- Mobile Navigation Toggler -->
                <div class="mobile-nav-toggler"><span class="icon flaticon-menu"></span></div>
                <!-- Main Menu -->
                <nav class="main-menu navbar-expand-md">
                    <div class="navbar-header">
                        <!-- Toggle Button -->
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>

                    <div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
                        <ul class="navigation clearfix">
                            <li ><a href="<?php echo e(url('/')); ?>">Home</a>
                                
                            </li>
                            <li class="dropdown"><a href="#">About</a>
                                <ul>
                                    <li><a href="about.html">About us</a></li>
                                    <li><a href="our_team.html">Our Team</a></li>
                                </ul>
                            </li>
                            <li ><a href="<?php echo e(route('home.cases')); ?>">Cases</a>
                                
                            </li>
                            <li class="dropdown"><a href="#">Our Services</a>
                                <ul>
                                    <li><a href="services_style_01.html">Services Style 01</a></li>
                                    <li><a href="services_style_02.html">Services Style 02</a></li>
                                    <li><a href="corporate_law.html">Corporate Law</a></li>
                                    <li><a href="real_estate_law.html">Real Estate Law</a></li>
                                    <li><a href="insurance_law.html">Insurance Law</a></li>
                                    <li><a href="family_law.html">Family Law</a></li>
                                </ul>
                            </li>
                            <li ><a href="<?php echo e(route('home.all.post')); ?>">Articles</a>
                                
                            </li>
                            
                            <li>    <?php if(Route::has('login')): ?>
                                <?php if(auth()->guard()->check()): ?>
                                    <a href="<?php echo e(url('/dashboard')); ?>" class="nav-link">Dashboard</a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('login')); ?>" class="nav-link">Log in</a>


                                <?php endif; ?>
                        <?php endif; ?></li>
                        </ul>
                    </div>
                </nav>

                <!-- Main Menu End-->
                <div class="outer-box clearfix">

                    <!-- Btn Box -->
                    <div class="btn-box">
                        <a href="<?php echo e(route('home.contact')); ?>" class="theme-btn btn-style-one"><span class="txt">Contact US</span></a>
                    </div>

                    <!-- Phone Box -->
                    <div class="phone-box">
                        <div class="box-inner">
                            <span class="icon flaticon-smartphone-1"></span>
                            Call US Today!
                            <strong><?php echo e($dashboard_settings->phone); ?></strong>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
    <!--End Header Upper-->

    <!-- Sticky Header  -->
    <div class="sticky-header">
        <div class="auto-container clearfix">
            <!--Logo-->
            <div class="logo pull-left">
                
                <a href="<?php echo e(url('/')); ?>" title=""><img src="<?php echo e(asset('/image/dashboard/'.$dashboard_settings->logo)); ?>" style="width: 100%;height:70px" alt="" title=""></a>
            </div>
            <!--Right Col-->
            <div class="pull-right">
                <!-- Main Menu -->
                <nav class="main-menu">
                    <!--Keep This Empty / Menu will come through Javascript-->
                </nav><!-- Main Menu End-->

                <!-- Main Menu End-->
                <div class="outer-box clearfix">

                    <!-- Btn Box -->
                    <div class="btn-box">
                        <a href="<?php echo e(route('home.contact')); ?>" class="theme-btn btn-style-two"><span class="txt">Contact US</span></a>
                    </div>

                    <!-- Mobile Navigation Toggler -->
                    <div class="mobile-nav-toggler"><span class="icon flaticon-menu"></span></div>

                </div>

            </div>
        </div>
    </div><!-- End Sticky Menu -->

    <!-- Mobile Menu  -->
    <div class="mobile-menu">
        <div class="menu-backdrop"></div>
        <div class="close-btn"><span class="icon flaticon-multiply"></span></div>

        <nav class="menu-box">
            <div class="nav-logo"><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/image/dashboard/'.$dashboard_settings->logo)); ?>" alt="" title=""></a></div>
            <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
        </nav>
    </div><!-- End Mobile Menu -->

</header>
<?php /**PATH D:\laragon\www\law\law\resources\views/frontend/shared/nav.blade.php ENDPATH**/ ?>